#ifndef RNACPP_H_INCLUDED
#define RNACPP_H_INCLUDED
#include "Sequence.h"
#include "DNA.h"
#include "RNA.h"

#include <fstream>
// constructors and destructor
template <class T>
RNA<T>::RNA(){}
///____________________________________________________________________________

template <class T>
RNA<T>::RNA(T * s, RNA_Type atype , int l)
{
    this->length = l;
    type = atype;
    this->seq = new T[this->length + 1];

    for(int i = 0 ; i < this -> length ; i++){
        this-> seq[i] = s[i];
    }

}
///____________________________________________________________________________
template <class T>
RNA<T>::RNA(string fileName , int index)
{
    int atype = this->loadSeqFromFile(fileName , index , "RNA");

    switch (atype)
    {
    case 0 :
        type = mRNA;
        break;
    case 1:
        type = pre_mRNA;
        break;
    case 2:
        type = mRNA_exon;
        break;
    case 3:
        type = mRNA_intron;
        break;
    }
}
template <class T>
RNA<T>::RNA(const RNA& rhs)
{
    type = rhs.type;
    this->seq = new T[rhs.length];
    //strcpy(this->seq , rhs.seq);///?????????????????????????????????/

    for(int i = 0 ; i < this->length ; i++){
        this->seq[i] = rhs.seq[i];
    }

    this->length = rhs.length;

}
///____________________________________________________________________________
template <class T>
RNA<T> RNA<T>:: operator= (const RNA& rhs)
{
    type = rhs.type;
    this->seq = new T[rhs.length];
    this->seq = rhs.seq;

    this->length = rhs.length;

    return *this;
}
///____________________________________________________________________________
template <class T>
RNA<T>::~RNA()
{}

///____________________________________________________________________________

// function to be overridden to print all the RNA information
template <class T>
void RNA<T>:: Print()
{
    cout << "RNA : " << endl;

    for(int i = 0 ; i < this->length ; i++ )
    {
        cout << this->seq[i] << " ";
    }
    cout << endl;
    cout << "the Type of RNA is : " << type <<endl;
}
///____________________________________________________________________________

// function to convert the RNA sequence into protein sequence
// using the codonsTable object
template <class T>
Protein<T> RNA<T>::ConvertToProtein(CodonsTable & table)
{
    T *ConvertedSeq = new T[(this->length/3)+1];

    for(int i = 0 , j = 0 ; i < this->length ; i+=3 , j++)
    {
        char tempSeq[4] = {this->seq[i] ,this->seq[i+1] , this->seq[i+2]};
        ConvertedSeq[j] = (table.getAminoAcid(tempSeq)).AminoAcid;
    }

    Protein<T> ConvertedProtein(ConvertedSeq, Hormon);

    return ConvertedProtein;
}
///____________________________________________________________________________

// function to convert the RNA sequence back to DNA
template <class T>
DNA<T> RNA<T>::ConvertToDNA()
{
    T *dnaSeq = new T [this->length];
    //strcpy(dnaSeq,seq);

    for(int i = 0 ; i < this->length ; i++){
        dnaSeq[i] = this->seq[i];
    }

    for (int i = 0 ; i < this->length ; i++ )
    {
        if (this->seq[i] == 'U')
            dnaSeq[i] = 'T';
        else
            dnaSeq[i] = this->seq[i];
    }

    DNA<T> dna (dnaSeq , promoter );

    return dna;
}




///***********************************************************************

ostream& operator<< ( ostream& out , RNA_Type atype)
{
    switch (atype)
    {
    case 0 :
        cout << "mRNA" << endl;
        break;
    case 1:
        cout << "pre_mRNA" << endl;
        break;
    case 2:
        cout << "mRNA_exon" << endl;
        break;
    case 3:
        cout << "mRNA_intron" << endl;
        break;
    }

    return out;
}

template <class T>
void RNA<T>::addtoFile(string FileName){

    int atype;

    switch(type)
    {
    case mRNA:
        atype = 0;
        break;
    case pre_mRNA:
        atype = 1;
        break;
    case mRNA_exon:
        atype = 2;
        break;
    case mRNA_intron:
        atype = 3;
        break;
    }

    this->saveSecToFile(FileName , this->getSeq() , atype);
}



#endif // RNACPP_H_INCLUDED
