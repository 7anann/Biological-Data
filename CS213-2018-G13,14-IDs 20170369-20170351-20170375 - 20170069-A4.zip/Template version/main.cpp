#include <iostream>
#include "BiologicalData.h"
using namespace std;

int main()
{

    int a[3] = {22 , 33 , 45};

    DNA < int> Seq(a ,promoter , 3);
    Seq.Print();

    RNA <int> Rna (a , mRNA , 3);
    Rna.Print();

    Protein<int> p1(a , Hormon , 2);
    p1.Print();

    return 0;
}
