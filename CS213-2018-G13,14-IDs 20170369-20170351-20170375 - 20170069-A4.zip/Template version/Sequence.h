#ifndef SEQUENCE_H
#define SEQUENCE_H

#include <cstring>
#include <cctype>
#include <string>
#include <fstream>

#include <iostream>
using namespace std;

enum DNA_Type{promoter, motif, tail, noncoding};
enum RNA_Type {mRNA, pre_mRNA, mRNA_exon, mRNA_intron};
enum Protein_Type {Hormon, Enzyme, TF, Cellular_Function};


template <class T>
class Sequence
{
  	protected:
        T * seq;
        int length;
    public:
 	 	// constructors and destructor
        Sequence();
        Sequence(int length ,  T* seq);
        Sequence(Sequence& rhs);

        virtual ~Sequence();
 	 	// pure virtual function that should be overridden because every
        // type of sequence has its own details to be printed
        virtual void Print(){

            for(int i = 0 ; i < length ; i++){
                cout << seq[i] << "  " << endl;
            }
        }
 	 	// friend function that will find the LCS (longest common
        // subsequence) between 2 sequences of any type, according to
        // polymorphism

        friend T* Align(Sequence<T> * s1, Sequence<T> * s2);

        friend T* globalAlign(Sequence<T> * s1, Sequence<T> * s2);

        int loadSeqFromFile(string filename , int index , string dataType);
        void saveSecToFile(string filename , T* InSeq , int dataType);

        int getlength();
        T* getSeq();
};




#include "Sequancecpp.h"

//int saveSecToFile(string filename , char* InSeq , int dataType);
#endif // SEQUENCE_H
