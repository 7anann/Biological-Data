#ifndef PROTEINCPP_H_INCLUDED
#define PROTEINCPP_H_INCLUDED

#include "Protein.h"
#include <fstream>

template <typename T>
Protein<T>::Protein(){}

template <typename T>
void Protein <T> :: Print(){
    for(int i = 0 ; i < this->length ; i++){
        cout << this->seq[i] << " ";
    }
}

// constructors and destructor
template <typename T>
Protein<T>::Protein(T * p , Protein_Type atype , int l)
{
    type = atype;
    this->seq = new T [l+1];

    for(int i = 0 ; i < l ; i++){
        this->seq[i] = p[i];
    }
    //strcpy( this->seq , p );
    this->length = l;///?????????????????????????????????
}

template <typename T>
Protein<T>::Protein(const Protein& p)
{
    type = p.type;

    this->seq = new T [p.length + 1];

    for(int i = 0 ; i < p.length ; i++){
        this->seq[i] = p.seq[i];
    }

    strcpy( this->seq , p.seq );

    this->length = p.length ;
}

template <typename T>
Protein<T>::Protein(string fileName , int index)
{
    int atype = this->loadSeqFromFile(fileName , index , "Protein");

    switch (atype)
    {
    case 0 :
        type = Hormon;
        break;
    case 1:
        type = Enzyme;
        break;
    case 2:
        type = TF;
        break;
    case 3:
        type = Cellular_Function;
        break;
    }
}

template <typename T>
Protein<T>::~Protein()
{}

template <typename T>
bool Protein<T>::operator== (Protein rhs){

    if(std::strcmp(this->seq , rhs.getSeq())==0 && type == rhs.type){
        return 1;
    }
    return 0;
}

// return an array of DNA sequences that can possibly
// generate that protein sequence
template <typename T>
DNA<T>* Protein<T>::GetDNAStrandsEncodingMe(DNA<T>  & bigDNA , CodonsTable & table)
{
    RNA<T> rna = bigDNA.ConvertToRNA();

    DNA<T>* ArrayOfStrands = new DNA<T>[bigDNA.getlength()];

    int index = 0 , nStrands = 0;
    for(int i = 0 ; i <= (rna.getlength() - this->length*3) ; i++)
    {
        T *TempSeq = new T [this->length*3];
        TempSeq = subchar(rna.getSeq() , index , this->length*3);
        index++;

        Protein<T> FlagProtein = ConvertCharToProtein(TempSeq , table);

        if(FlagProtein == *this)
        {
            T *DNAsubSeq = new T [this->length*3];
            DNAsubSeq = subchar(bigDNA.getSeq() , index , this->length*3);

            DNA<T> strand(DNAsubSeq , promoter);

            strand.Print();

            ArrayOfStrands[nStrands++] = strand;

            delete[] DNAsubSeq;
        }
    }
    return ArrayOfStrands;
}

///*************************************************************************
ostream& operator<< ( ostream& out , Protein_Type atype)
{
    switch (atype)
    {
    case 0 :
        cout << "Hormon" << endl;
        break;
    case 1:
        cout << "Enzyme" << endl;
        break;
    case 2:
        cout << "TF" << endl;
    case 3:
        cout << "Cellular_Function" << endl;
        break;
    default:
        cout<<"no type\n";
        break;
    }
    return out;
}
///________________________________________________________________
template <typename T>
T* subchar(T* arr, int start , int n)
{
    T* output = new T [n];

    int index = 0;

    for (int i = 0 ; i < n ; i++)
    {
        output[i] = arr[ index + start ];
        index ++;
    }

    return output;
}

///________________________________________________________________
template <typename T>
Protein<T> ConvertCharToProtein(T* Seq , CodonsTable & table)
{
    T *ConvertedSeq = new T[(strlen(Seq)/3)];

    for(int i = 0 , j = 0 ; i < strlen(Seq) ; i+=3 , j++)
    {
        T tempSeq[4] = {Seq[i] ,Seq[i+1] , Seq[i+2]};

        ConvertedSeq[j] = (table.getAminoAcid(tempSeq)).AminoAcid;
    }

    Protein<T> ConvertedProtein(ConvertedSeq, Hormon);

    return ConvertedProtein;
}



template <typename T>
void Protein<T>::addtoFile(string FileName){

    int atype;

    switch(type)
    {
    case Hormon:
        atype = 0;
        break;
    case Enzyme:
        atype = 1;
        break;
    case TF:
        atype = 2;
        break;
    case Cellular_Function:
        atype = 3;
        break;
    }

    this->saveSecToFile(FileName , this->getSeq() , atype);
}



#endif // PROTEINCPP_H_INCLUDED
