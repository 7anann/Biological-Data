#ifndef BIOLOGICALDATA_H_INCLUDED
#define BIOLOGICALDATA_H_INCLUDED

#include "Sequence.h"
#include "DNA.h"
#include "RNA.h"
#include "CodonsTable.h"
#include "Protein.h"



#endif // BIOLOGICALDATA_H_INCLUDED
