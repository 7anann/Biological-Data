#ifndef PROTEIN_H
#define PROTEIN_H

#include "DNA.h"
#include "CodonsTable.h"
#include "RNA.h"

using namespace std;
ostream& operator<< ( ostream& out , Protein_Type atype); /// just for the enum


template <typename T>
class Protein : public Sequence <T>
{
  	private:
        Protein_Type type;
    public:
 	 	// constructors and destructor
 	 	Protein();
 	 	Protein(string fileName , int index);
 	 	Protein(T * p , Protein_Type atype , int l);
 	 	Protein(const Protein& protein);

 	 	bool operator== (Protein rhs);

 	 	virtual ~Protein();
 	 	void Print();
 	 	// return an array of DNA sequences that can possibly
                // generate that protein sequence

        void addtoFile(string filename);

        DNA<T>* GetDNAStrandsEncodingMe(DNA<T> & bigDNA , CodonsTable & table);
};

template <typename T>
T* subchar(T* arr, int start , int n);

template <typename T>
Protein<T> ConvertCharToProtein(T* Seq , CodonsTable & table);

#include "Proteincpp.h"

#endif // PROTEIN_H
