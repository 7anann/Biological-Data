#ifndef SEQUANCECPP_H_INCLUDED
#define SEQUANCECPP_H_INCLUDED

#include <algorithm>


#include "Sequence.h"

template <class T>
int Sequence<T>:: getlength()
{
    return length;
}

template <class T>
T* Sequence<T>:: getSeq()
{
    return seq;
}

// constructors and destructor
template <class T>
Sequence<T>::Sequence()
{
//    this->seq = nullptr;
//    this->length = 0;
}

template <class T>
Sequence<T>::Sequence(int length , T* seq)
{
    this->seq = new T [length];
    for(int i = 0 ; i < length ; i++){
        this->seq[i] = seq[i];
    }

    this -> length = length;
}

template <class T>
Sequence<T>::Sequence(Sequence& rhs)
{
    length = rhs.length;

    delete []seq;
    seq = new T[rhs.length];
    seq = rhs.seq;
}

template <class T>
Sequence<T>::~Sequence()
{
    delete []seq;
}
// friend function that will find the LCS (longest common
// subsequence) between 2 sequences of any type, according to
// polymorphism

template <class T2>
T2* Align(Sequence<T2> * s1, Sequence<T2> * s2)
{
    T2 seq1 = new T2 [s1-> length];
    T2 seq2 = new T2 [s2-> length];
    T2 LCS;

     for(int i = 0 ; i < s1->length ; i++ ){
        seq1[i] = s1->seq[i];
    }
    for(int i = 0 ; i < s2->length ; i++ ){
        seq2[i] = s2->seq[i];
    }

    int seq1Size = s1-> length;
    int seq2Size = s2-> length;

    int intMatrix[seq1Size + 1][seq2Size + 1];

    for( int i = 0 ; i < seq1Size + 1 ; i++)///intializing the intMatrix with zeros
    {
        for( int j = 0 ; j < seq2Size + 1 ; j++)
        {
            intMatrix [i][j] = 0;
        }
    }

    for( int i = 1 ; i < seq1Size + 1 ; i++ )
    {
        for(int j = 1 ; j < seq2Size + 1 ; j++)
        {
            if( seq1[i - 1] == seq2[j - 1] )
                intMatrix[i][j] = intMatrix[i - 1][j - 1] + 1;

            else if( intMatrix[i - 1][j] > intMatrix[i][j - 1] )
                intMatrix[i][j] = intMatrix[i - 1][j];

            else
                intMatrix[i][j] = intMatrix[i][j - 1];

        }
    }

    int LCSsize = intMatrix[seq1Size][seq2Size];

    LCS = new T2 [LCSsize];
    int k = 0;

    for( int i = seq1Size - 1 ; i >= 0 ; i-- )
    {
        for( int j = seq2Size - 1 ; j >= 0 ; j-- )
        {
            if( intMatrix[i][j] != intMatrix[i - 1][j - 1] )
            {
                LCS[k++] = seq1[i];
                i = i - 1;
                j = j - 1;
                break;
            }

        }
    }

    LCS[LCSsize]='\0';
    reverse (LCS,LCS +LCSsize);


    return LCS;
}

template <class T2>
T2* globalAlign(Sequence<T2> * s1, Sequence<T2> * s2){

    T2* seq1,* seq2;

    seq1 = new T2[s1.length];
    seq2 = new T2[s2.length];

    for(int i = 0 ; i < s1.length ; i++ ){
        seq1[i] = s1.seq[i];
    }
    for(int i = 0 ; i < s2.length ; i++ ){
        seq2[i] = s2.seq[i];
    }


    cout<<seq1<<" "<<seq2<<endl;
    int intMat[s1.length+1][s2.length+1];
    int seq1Size = s1.length+1;
    int seq2Size = s2.length+1;

    for(int i = 0  ; i < seq1Size ; i++ )
    {
        for(int j = 0 ; j < seq2Size ; j++ )
        {
            intMat[i][j] = 0;
        }
    }

    for(int i = 1  ; i < seq1Size ; i++ )
    {
        intMat[i][0] = intMat[i-1][0] - 1;
        for(int j = 1 ; j < seq2Size ; j++ )
        {
            intMat[0][j] = intMat[0][j-1] - 1;
        }
    }
    int choice[3];

    for (int i = 1 ; i < seq1Size ; i++ ) ///"GCATGCU" ,"GATTACA"
    {
        for (int j = 1 ; j < seq2Size ; j++)
        {
            if ( seq1[i-1] == seq2[j-1] )
            {
                choice[0] = intMat [i-1][j-1] + 1;
                choice[1] = intMat [i][j-1] - 1;
                choice[2] = intMat [i-1][j] - 1;
                intMat[i][j] = *max_element (choice,choice+3);
            }
            else
            {
                choice[0] = intMat [i-1][j-1] - 1;
                choice[1] = intMat [i][j-1] - 1;
                choice[2] = intMat [i-1][j] - 1;
                intMat[i][j] = *max_element (choice,choice+3);
            }
        }
    }


    T2 *result = new T2[100];
    int k = 2,choice1[3];

    result[0] = '/0';
    result[1] = seq2[seq2Size - 2];

    int i = seq1Size - 2;
    int j = seq2Size - 2;

    for( i ; i > 0 ;  ){
        for( j ; j > 0 ; ){
            if(seq1[i-1] == seq2[j-1] )
            {
                choice1[0] = intMat[i-1][j-1] + 1;
                choice1[1] = intMat[i-1][j] - 1;
                choice1[2] = intMat[i][j-1] - 1;
            }
            else
            {
                choice1[0] = intMat[i-1][j-1] - 1;
                choice1[1] = intMat[i-1][j] - 1;
                choice1[2] = intMat[i][j-1] - 1;

            }

            if( &choice1[0] == max_element (choice1,choice1+3))
            {
                result [k++] = seq2[j-1];
                i--;
                j--;
                break;
            }
            else if( &choice1[1] == max_element (choice1,choice1+3))
            {
                result [k++] = '-';
                i--;
                break;

            }
            else if(&choice1[2] == max_element (choice1,choice1+3))
            {
                result [k++] = seq2[i];
                j--;
                break;
            }
        }
    }
    reverse(result,result+k);
    cout<<result;

}


template <class T>
int Sequence<T>::loadSeqFromFile(string fileName , int index , string dataType)
{
    ifstream SequenceFlie;
    SequenceFlie.open(fileName , ios::in);

    int indx;
    string newSeq;
    int atype;
    int line = 0;

    while(!SequenceFlie.eof() && !SequenceFlie.fail()){
        SequenceFlie >> indx >> newSeq >> atype;
        if(index == indx)
            break;
    /// This commented code is fore exceptions , but it doesn't word :(
    /*
        if(line == 0){
            string data;
            RNAFlie >> data;
            if(data != "DNA")
                throw "This is not the required file";
        }
        else{
            RNAFlie >> indx >> newSeq >> atype;
            if(index == indx)
                break;
        }
        line ++;
    */

    }

    length = newSeq.size();

    seq = new T [newSeq.size()];
    for(int i = 0 ; i < newSeq.size() ; i++)
            seq[i] = newSeq[i];

    return atype;
}

template <class T>
void Sequence<T>::saveSecToFile(string filename , T* InSeq , int dataType)
{
    ifstream readDatafile;
    readDatafile.open(filename , ios::in );

    int index = 6 , atype;

    string data;

    while(!readDatafile.eof() && !readDatafile.fail()){
        readDatafile >> index >> data >> atype;
    }
    readDatafile.close();

    ofstream AddtoFile;
    AddtoFile.open(filename , ios::out | ios::app);

    AddtoFile << endl << index+1 << "  " << InSeq << "  " << dataType;

}


#endif // SEQUANCECPP_H_INCLUDED
